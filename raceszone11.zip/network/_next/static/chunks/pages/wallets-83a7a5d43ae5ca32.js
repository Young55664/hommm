(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [363], { 7642: function(e, t, a) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/wallets", function() { return a(3738) }]) }, 3738: function(e, t, a) { "use strict";
            a.r(t), a.d(t, { default: function() { return p } }); var n = a(5893),
                l = a(2962),
                s = a(7294),
                r = a(3798),
                i = a(2989),
                c = a(3625),
                o = a(9830),
                d = a(1185),
                u = function(e) { var t = e.name,
                        a = e.icon; return (0, n.jsxs)("div", { className: "flex h-[200px] w-[250px] cursor-pointer flex-col items-center justify-around overflow-hidden rounded-[18px] border-[1px] border-transparent bg-card transition-all duration-[500ms] hover:border-primary-blue2 md:w-[200px]", children: [(0, n.jsx)("div", { className: "mx-auto flex w-[80%] items-center justify-center", children: (0, n.jsx)("div", { className: "relative h-32 w-32 overflow-hidden rounded-full bg-white/[0.03] opacity-80 saturate-150", children: (0, n.jsx)(d.Z, { src: "/wallets/".concat(a, ".png"), alt: "".concat(a, " wallet image"), layout: "fill", objectFit: "contain" }) }) }), (0, n.jsx)("div", { className: "text-center text-xl capitalize", children: t })] }) },
                x = a(1499),
                m = function() { var e = (0, s.useState)(""),
                        t = e[0],
                        a = e[1],
                        l = (0, s.useState)(""),
                        r = l[0],
                        i = l[1],
                        c = (0, s.useState)(!1),
                        d = c[0],
                        m = c[1]; return (0, n.jsxs)("section", { id: "wallets", className: "container my-12 min-h-screen bg-w bg-top py-10", children: [(0, n.jsxs)("div", { className: "rcontainer", children: [(0, n.jsxs)("div", { className: "mx-auto mb-4 w-full max-w-md text-center md:max-w-lg lg:max-w-xl", children: [(0, n.jsx)("h3", { className: "mb-3 bg-lg1 bg-clip-text text-lg font-bold text-transparent sm:text-xl", children: "CONNECT YOUR WALLETS NOW" }), (0, n.jsx)("p", { className: "mb-4 text-sm font-light md:text-base lg:text-lg", children: "Connect to your wallets and take full control of your crypto wallets in one place. Fully decentralized and completely secured." })] }), (0, n.jsx)("div", { className: "relative mt-8 grid gap-y-4 sm:grid-cols-2 sm:gap-4 sm:gap-y-6 md:grid-cols-3 lg:grid-cols-4 lg:gap-y-8", children: o.lH.map((function(e, t) { return (0, n.jsx)("div", { "data-aos": "fade-up", "data-aos-delay": 30 * (t + 1), className: "mx-auto max-w-[250px] md:max-w-[200px]", onClick: function() { return t = e.name, n = e.icon, a(t), i(n), void m(!0); var t, n }, children: (0, n.jsx)(u, { icon: e.icon, name: e.name }) }, t) })) })] }), (0, n.jsx)(x.Z, { isOpen: d, closeModal: function() { return m(!1) }, walletName: t, icon: r })] }) },
                p = function() { return (0, n.jsxs)(n.Fragment, { children: [(0, n.jsx)(l.PB, { title: "Easily Manage your Wallets" }), (0, n.jsx)(i.Z, { showHeroAndPoweredBy: !1 }), (0, n.jsx)(m, {}), (0, n.jsx)(c.Z, {}), (0, n.jsx)(r.Z, {})] }) } } },
    function(e) { e.O(0, [445, 874, 228, 556, 787, 921, 847, 499, 774, 888, 179], (function() { return t = 7642, e(e.s = t); var t })); var t = e.O();
        _N_E = t }
]);